//��������Screen0����������ID
#define  _SCREEN_SCREEN0                                                       0

//��������Screen1����������ID
#define  _SCREEN_SCREEN1                                                       1

//��������Screen2����������ID
#define  _SCREEN_SCREEN2                                                       2

//��������Screen3����������ID
#define  _SCREEN_SCREEN3                                                       3

//��������Screen4����������ID
#define  _SCREEN_SCREEN4                                                       4

//��������Screen5����������ID
#define  _SCREEN_SCREEN5                                                       5

//��������Screen6����������ID
#define  _SCREEN_SCREEN6                                                       6

//��������Screen7����������ID
#define  _SCREEN_SCREEN7                                                       7

//��������Screen8����������ID
#define  _SCREEN_SCREEN8                                                       8

//��������Screen9����������ID
#define  _SCREEN_SCREEN9                                                       9

//��������Screen10����������ID
#define  _SCREEN_SCREEN10                                                     10

//��������Screen11����������ID
#define  _SCREEN_SCREEN11                                                     11

//��������Screen12����������ID
#define  _SCREEN_SCREEN12                                                     12

//��������Screen13����������ID
#define  _SCREEN_SCREEN13                                                     13

#define  _BTN_SCREEN0_BUTTON4                                                 21

#define  _ANIMATION_SCREEN0_ICON2                                              1

//����Screen0�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON3                                                    1

#define  _ANIMATION_SCREEN0_ICON3                                              3

//����Screen0�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON1                                                    1

#define  _ANIMATION_SCREEN0_ICON1                                              2

//����Screen0�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON4                                                    1

#define  _ANIMATION_SCREEN0_ICON4                                              4

//����Screen0�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON5                                                    1

#define  _ANIMATION_SCREEN0_ICON5                                              5

//����Screen0�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON6                                                    1

#define  _ANIMATION_SCREEN0_ICON6                                              6

//����Screen0�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON7                                                    1

#define  _ANIMATION_SCREEN0_ICON7                                              7

//����Screen0�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON8                                                    1

#define  _ANIMATION_SCREEN0_ICON8                                              8

//����Screen0�ж����ؼ�Icon9ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON9                                                    1

#define  _ANIMATION_SCREEN0_ICON9                                              9

//����Screen0�ж����ؼ�Icon10ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON10                                                   1

#define  _ANIMATION_SCREEN0_ICON10                                            10

//����Screen0�ж����ؼ�Icon11ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON11                                                   1

#define  _ANIMATION_SCREEN0_ICON11                                            11

//����Screen0�ж����ؼ�Icon12ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON12                                                   1

#define  _ANIMATION_SCREEN0_ICON12                                            12

//����Screen0�ж����ؼ�Icon13ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON13                                                   1

#define  _ANIMATION_SCREEN0_ICON13                                            13

//����Screen0�ж����ؼ�Icon14ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON14                                                   1

#define  _ANIMATION_SCREEN0_ICON14                                            14

//����Screen0�ж����ؼ�Icon15ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON15                                                   1

#define  _ANIMATION_SCREEN0_ICON15                                            15

//����Screen0�ж����ؼ�Icon16ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON16                                                   1

#define  _ANIMATION_SCREEN0_ICON16                                            16

//����Screen0�ж����ؼ�Icon17ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON17                                                   1

#define  _ANIMATION_SCREEN0_ICON17                                            17

//����Screen0�ж����ؼ�Icon18ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON18                                                   1

#define  _ANIMATION_SCREEN0_ICON18                                            18

//����Screen0�ж����ؼ�Icon19ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON19                                                   1

#define  _ANIMATION_SCREEN0_ICON19                                            19

//����Screen0�ж����ؼ�Icon20ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON20                                                   1

#define  _ANIMATION_SCREEN0_ICON20                                            20

//����Screen0�ж����ؼ�Icon21ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON21                                                   1

#define  _ANIMATION_SCREEN0_ICON21                                            29

//����Screen0�ж����ؼ�Icon22ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON22                                                   1

#define  _ANIMATION_SCREEN0_ICON22                                            77

//����Screen0�ж����ؼ�Icon23ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON23                                                   1

#define  _ANIMATION_SCREEN0_ICON23                                            78

//����Screen0�ж����ؼ�Icon24ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON24                                                   1

#define  _ANIMATION_SCREEN0_ICON24                                            81

//����Screen0�ж����ؼ�Icon25ʹ�õ�ͼƬ
#define  _IMG_SCREEN0_ICON25                                                   1

#define  _ANIMATION_SCREEN0_ICON25                                            82

//����Screen0�а�ťButton1����ʱ��ͼƬ
#define  _IMG_SCREEN0_BUTTON1_UP                                               0

#define  _BTN_SCREEN0_BUTTON1                                                 22

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY5                                      20

#define  _BTN_SCREEN1_BUTTON4                                                  4

#define  _BTN_SCREEN1_BUTTON8                                                  8

#define  _BTN_SCREEN1_BUTTON1                                                  1

#define  _BTN_SCREEN1_BUTTON2                                                  2

//����Screen1�а�ťButton3����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON3_UP                                               7

//����Screen1�а�ťButton3����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON3_DOWN                                             8

#define  _BTN_SCREEN1_BUTTON3                                                  3

#define  _BTN_SCREEN1_BUTTON5                                                  5

#define  _BTN_SCREEN1_BUTTON6                                                  6

#define  _BTN_SCREEN1_BUTTON7                                                 10

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY3                                      22

#define  _BTN_SCREEN1_BUTTON10                                                15

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY2                                      16

#define  _BTN_SCREEN1_BUTTON11                                                17

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY4                                      18

#define  _SELECTOR_SCREEN1_SELECTOR2                                          23

//����Screen1�а�ťButton12����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON12_DOWN                                           14

#define  _BTN_SCREEN1_BUTTON12                                                 7

#define  _SELECTOR_SCREEN1_SELECTOR1                                          24

//����Screen1�а�ťButton13����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON13_UP                                             13

//����Screen1�а�ťButton13����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON13_DOWN                                           14

#define  _BTN_SCREEN1_BUTTON13                                                25

//����Screen1�а�ťButton14����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON14_UP                                             15

//����Screen1�а�ťButton14����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON14_DOWN                                           16

#define  _BTN_SCREEN1_BUTTON14                                                12

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY1                                      13

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY6                                      26

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY7                                      30

#define  _TXT_DIS__SCREEN1_TEXT_DISPLAY9                                      34

#define  _BTN_SCREEN1_BUTTON9                                                  9

//����Screen1�а�ťButton15����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON15_UP                                             20

//����Screen1�а�ťButton15����ʱ��ͼƬ
#define  _IMG_SCREEN1_BUTTON15_DOWN                                           21

#define  _BTN_SCREEN1_BUTTON15                                                38

#define  _SELECTOR_SCREEN1_SELECTOR3                                          52

#define  _SELECTOR_SCREEN1_SELECTOR4                                          51

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY3                                       5

#define  _BTN_SCREEN2_BUTTON8                                                  8

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY1                                       4

#define  _BTN_SCREEN2_BUTTON2                                                 17

#define  _SELECTOR_SCREEN2_SELECTOR2                                          23

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY9                                      30

#define  _BTN_SCREEN2_BUTTON7                                                 32

#define  _BTN_SCREEN2_BUTTON5                                                 40

#define  _BTN_SCREEN2_BUTTON6                                                 41

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY2                                      11

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY4                                      14

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY7                                      22

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY8                                      26

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY5                                      19

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY6                                      33

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY10                                     44

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY11                                     47

#define  _SELECTOR_SCREEN2_SELECTOR3                                          53

#define  _SELECTOR_SCREEN2_SELECTOR1                                          54

#define  _TXT_DIS__SCREEN2_TEXT_DISPLAY12                                     56

#define  _BTN_SCREEN3_BUTTON8                                                  8

//����Screen3�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN3_BUTTON2_UP                                              23

//����Screen3�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN3_BUTTON2_DOWN                                            24

#define  _BTN_SCREEN3_BUTTON2                                                 15

#define  _SELECTOR_SCREEN3_SELECTOR2                                          23

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY6                                      19

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY10                                     35

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY11                                     38

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY2                                       9

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY4                                      14

#define  _BTN_SCREEN3_BUTTON1                                                 12

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY7                                      25

#define  _TXT_DIS__SCREEN3_TEXT_DISPLAY3                                       2

#define  _BTN_SCREEN4_BUTTON8                                                  8

#define  _TXT_DIS__SCREEN4_TEXT_DISPLAY1                                       4

#define  _TXT_DIS__SCREEN4_TEXT_DISPLAY3                                      11

#define  _TXT_DIS__SCREEN4_TEXT_DISPLAY5                                      17

#define  _TXT_DIS__SCREEN4_TEXT_DISPLAY6                                      20

#define  _TXT_DIS__SCREEN4_TEXT_DISPLAY8                                      28

#define  _TXT_DIS__SCREEN4_TEXT_DISPLAY9                                      30

#define  _BTN_SCREEN4_BUTTON2                                                  1

#define  _BTN_SCREEN5_BUTTON8                                                  8

#define  _TXT_DIS__SCREEN5_TEXT_DISPLAY1                                       3

#define  _TXT_DIS__SCREEN5_TEXT_DISPLAY6                                      19

#define  _TXT_DIS__SCREEN5_TEXT_DISPLAY2                                       6

#define  _TXT_DIS__SCREEN5_TEXT_DISPLAY3                                       7

#define  _ANIMATION_SCREEN5_ICON3                                             10

//����Screen5�а�ťButton12����ʱ��ͼƬ
#define  _IMG_SCREEN5_BUTTON12_UP                                             19

//����Screen5�а�ťButton12����ʱ��ͼƬ
#define  _IMG_SCREEN5_BUTTON12_DOWN                                           14

#define  _BTN_SCREEN5_BUTTON12                                                13

#define  _SELECTOR_SCREEN5_SELECTOR1                                          24

//����Screen5�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN5_BUTTON5_UP                                               9

//����Screen5�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN5_BUTTON5_DOWN                                            10

#define  _BTN_SCREEN5_BUTTON5                                                 16

#define  _BTN_SCREEN6_BUTTON8                                                  8

#define  _TXT_DIS__SCREEN6_TEXT_DISPLAY2                                       6

#define  _TXT_DIS__SCREEN6_TEXT_DISPLAY1                                       2

#define  _TXT_DIS__SCREEN6_TEXT_DISPLAY3                                       7

#define  _BTN_SCREEN6_BUTTON6                                                 11

#define  _BTN_SCREEN7_BUTTON8                                                  8

#define  _BTN_SCREEN7_BUTTON1                                                  1

//����Screen7�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN7_BUTTON2_UP                                              34

#define  _BTN_SCREEN7_BUTTON2                                                  2

#define  _BTN_SCREEN7_BUTTON3                                                  3

#define  _BTN_SCREEN7_BUTTON4                                                  4

//����Screen7�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN7_BUTTON5_UP                                              35

#define  _BTN_SCREEN7_BUTTON5                                                  5

#define  _BTN_SCREEN8_BUTTON4                                                 22

#define  _TXT_DIS__SCREEN8_TEXT_DISPLAY2                                       6

#define  _BTN_SCREEN8_BUTTON3                                                  3

#define  _TXT_DIS__SCREEN8_TEXT_DISPLAY1                                       2

//����Screen8�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN8_BUTTON5_UP                                              35

#define  _BTN_SCREEN8_BUTTON5                                                  7

//����Screen8�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN8_BUTTON2_UP                                              34

#define  _BTN_SCREEN8_BUTTON2                                                 16

#define  _SELECTOR_SCREEN8_SELECTOR1                                          54

#define  _BTN_SCREEN8_BUTTON1                                                 13

#define  _SELECTOR_SCREEN8_SELECTOR2                                          14

#define  _SELECTOR_SCREEN8_SELECTOR3                                          23

#define  _BTN_SCREEN9_BUTTON4                                                 21

#define  _BTN_SCREEN9_BUTTON2                                                  6

#define  _TXT_DIS__SCREEN9_TEXT_DISPLAY1                                      13

#define  _TXT_DIS__SCREEN9_TEXT_DISPLAY5                                       1

#define  _TXT_DIS__SCREEN9_TEXT_DISPLAY8                                      28

#define  _BTN_SCREEN9_BUTTON3                                                  3

#define  _TXT_DIS__SCREEN9_TEXT_DISPLAY2                                       5

#define  _TXT_DIS__SCREEN9_TEXT_DISPLAY4                                      24

#define  _TXT_DIS__SCREEN10_TEXT_DISPLAY3                                     10

#define  _RTC_SCREEN10_RTC1                                                   14

//����Screen10�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN10_BUTTON5_UP                                             35

#define  _BTN_SCREEN10_BUTTON5                                                 7

#define  _TXT_DIS__SCREEN11_TEXT_DISPLAY3                                     22

#define  _TXT_DIS__SCREEN11_TEXT_DISPLAY4                                     23

#define  _TXT_DIS__SCREEN11_TEXT_DISPLAY5                                     56

#define  _TXT_DIS__SCREEN11_TEXT_DISPLAY6                                     57

//����Screen11�а�ťButton4����ʱ��ͼƬ
#define  _IMG_SCREEN11_BUTTON4_UP                                              0

#define  _BTN_SCREEN11_BUTTON4                                                21

//����Screen11�а�ťButton1����ʱ��ͼƬ
#define  _IMG_SCREEN11_BUTTON1_UP                                              0

#define  _BTN_SCREEN11_BUTTON1                                                 1

//����Screen12�а�ťButton7����ʱ��ͼƬ
#define  _IMG_SCREEN12_BUTTON7_DOWN                                           55

#define  _BTN_SCREEN12_BUTTON7                                                10

#define  _BTN_SCREEN12_BUTTON9                                                 9

//����Screen12�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN12_BUTTON2_DOWN                                           57

#define  _BTN_SCREEN12_BUTTON2                                                 3

#define  _BTN_SCREEN13_BUTTON4                                                 1

#define  _TXT_DIS__SCREEN13_TEXT_DISPLAY5                                     20

